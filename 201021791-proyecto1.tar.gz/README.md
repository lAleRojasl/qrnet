# QR Net
Proyecto 1 - Redes  

Required tools:  
  - Python 3.6.7  
  - PIP3   
  - Net Tools (Optional)  
  - Scapy:   
  	$ sudo pip3 install scapy  
	$ sudo pip3 install python-scapy3  
	$ sudo pip3 install ipython3  
  - Dumbnet:  
    	$ sudo apt install libdnet python-dumbnet  
  - Mesh Networking  
    	$ sudo pip3 install mesh-networking  

Install:  
	$cd qrnet  
	$sudo python3 setup.py install  
